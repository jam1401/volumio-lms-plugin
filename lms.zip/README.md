# volumio-lms-plugin
Manage Logitech Media Server in Volumio

The button for the webconsole only works in Volumio 2.260 and up. Please note that the MyVolumio versions are (by default) 2.260 and up.

Installation can be done when PRs into Volumio are accepted.

Manual installation is possible by (simplified):

1. Downloading the repo;
2. Installing modules (npm i)
3. volumio plugin install
